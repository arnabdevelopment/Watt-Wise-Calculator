/* WattWise — ui.js
   Formatting helpers, toast notifications, modal sheets. */

const UI = {
  state: { settings: null },

  fmtMoney(n, settings) {
    const s = settings || UI.state.settings || Storage.DEFAULT_SETTINGS;
    const sym = s.currencySymbol || '₹';
    const v = Number(n) || 0;
    return sym + v.toLocaleString('en-IN', { maximumFractionDigits: 0 });
  },

  fmtMoneyPrecise(n, settings) {
    const s = settings || UI.state.settings || Storage.DEFAULT_SETTINGS;
    const sym = s.currencySymbol || '₹';
    const v = Number(n) || 0;
    return sym + v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  fmtUnits(n) {
    const v = Number(n) || 0;
    return v.toLocaleString('en-IN', { maximumFractionDigits: 1 });
  },

  fmtDate(dateStr) {
    const d = new Date(dateStr);
    if (isNaN(d)) return '—';
    const day = String(d.getDate()).padStart(2, '0');
    const monthsShort = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const month = monthsShort[d.getMonth()];
    const year = d.getFullYear();
    return `${day} ${month} ${year}`;
  },

  fmtDateLong(dateStr) {
    const d = new Date(dateStr);
    const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    const dow = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    return {
      full: `${d.getDate()} ${months[d.getMonth()].toUpperCase()} ${d.getFullYear()}`,
      dow: dow[d.getDay()].toUpperCase(),
    };
  },

  toISODateInputValue(d) {
    const dt = d ? new Date(d) : new Date();
    const off = dt.getTimezoneOffset();
    const local = new Date(dt.getTime() - off * 60000);
    return local.toISOString().slice(0, 10);
  },

  toast(message, type = 'default') {
    const root = document.getElementById('toast-root');
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    const icon = type === 'success' ? Icons.check : type === 'error' ? Icons.x : '';
    el.innerHTML = `${icon}<span>${message}</span>`;
    root.appendChild(el);
    setTimeout(() => {
      el.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
      el.style.opacity = '0';
      el.style.transform = 'translateY(8px)';
      setTimeout(() => el.remove(), 260);
    }, 2200);
  },

  showModal({ title, text, confirmLabel = 'Confirm', cancelLabel = 'Cancel', danger = false, onConfirm }) {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.innerHTML = `
      <div class="modal-sheet">
        <div class="modal-title">${title}</div>
        <div class="modal-text">${text}</div>
        <div class="modal-actions">
          <button class="btn btn-outline" data-act="cancel">${cancelLabel}</button>
          <button class="btn ${danger ? 'btn-danger-outline' : 'btn-primary'}" data-act="confirm">${confirmLabel}</button>
        </div>
      </div>`;
    document.body.appendChild(backdrop);

    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop || e.target.dataset.act === 'cancel') {
        backdrop.remove();
      } else if (e.target.closest('[data-act="confirm"]')) {
        backdrop.remove();
        onConfirm && onConfirm();
      }
    });
  },

  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');
  },

  /**
   * Wires a "number stepper" control: a text input plus modern +/- buttons,
   * replacing the browser's native spinner arrows.
   * Expects markup produced by numberStepperHTML() (see app.js).
   */
  wireStepper(wrapEl, { min = null, max = null, step = 1, onChange } = {}) {
    const input = wrapEl.querySelector('.stepper-input');
    const dec = wrapEl.querySelector('[data-step="dec"]');
    const inc = wrapEl.querySelector('[data-step="inc"]');

    const clamp = (v) => {
      if (min !== null && v < min) v = min;
      if (max !== null && v > max) v = max;
      return v;
    };
    const roundToStep = (v) => Math.round(v / step) * step;

    dec.addEventListener('click', () => {
      const v = clamp(roundToStep((parseFloat(input.value) || 0) - step));
      input.value = trimNum(v);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      onChange && onChange(v);
    });
    inc.addEventListener('click', () => {
      const v = clamp(roundToStep((parseFloat(input.value) || 0) + step));
      input.value = trimNum(v);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      onChange && onChange(v);
    });
  },
};

function trimNum(v) {
  return Math.round(v * 100) / 100;
}

window.UI = UI;
