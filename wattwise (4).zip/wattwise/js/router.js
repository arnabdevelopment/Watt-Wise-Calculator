/* WattWise — router.js */

const Router = {
  routes: {},
  current: null,

  register(path, renderFn) {
    Router.routes[path] = renderFn;
  },

  init() {
    window.addEventListener('hashchange', Router.handle);
    Router.handle();
  },

  navigate(path) {
    if (location.hash === '#' + path) {
      Router.handle();
    } else {
      location.hash = path;
    }
  },

  parse() {
    const hash = location.hash.replace(/^#/, '') || '/dashboard';
    const [path, query] = hash.split('?');
    const params = new URLSearchParams(query || '');
    return { path, params };
  },

  async handle() {
    const { path, params } = Router.parse();
    const base = path.split('/').slice(0, 2).join('/');
    let fn = Router.routes[path] || Router.routes[base];

    if (!fn) {
      fn = Router.routes['/dashboard'];
    }
    Router.current = path;
    document.getElementById('app-root').scrollTop = 0;
    window.scrollTo(0, 0);
    await fn(params, path);
    Router.updateNavActive(path);
  },

  updateNavActive(path) {
    document.querySelectorAll('.nav-item').forEach((el) => {
      const route = el.dataset.route;
      const isActive = path === route || path.startsWith(route + '/');
      el.classList.toggle('active', isActive);
    });
  },
};

window.Router = Router;
