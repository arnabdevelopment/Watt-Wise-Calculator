/* WattWise — storage.js
   IndexedDB wrapper. Two object stores: "readings" and "settings".
   Everything lives on-device — nothing is ever sent to a server. */

const DB_NAME = 'WattWiseDB';
const DB_VERSION = 1;
const STORE_READINGS = 'readings';
const STORE_SETTINGS = 'settings';

let dbInstance = null;

function openDB() {
  if (dbInstance) return Promise.resolve(dbInstance);
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_READINGS)) {
        const store = db.createObjectStore(STORE_READINGS, { keyPath: 'id' });
        store.createIndex('readingDate', 'readingDate', { unique: false });
        store.createIndex('totalBill', 'totalBill', { unique: false });
        store.createIndex('units', 'units', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
      }
    };

    req.onsuccess = (e) => {
      dbInstance = e.target.result;
      resolve(dbInstance);
    };
    req.onerror = (e) => reject(e.target.error);
  });
}

function uuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

const Storage = {
  // ---------- Readings ----------
  async addReading(reading) {
    const db = await openDB();
    reading.id = reading.id || uuid();
    reading.createdAt = reading.createdAt || Date.now();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_READINGS, 'readwrite');
      tx.objectStore(STORE_READINGS).put(reading);
      tx.oncomplete = () => resolve(reading);
      tx.onerror = (e) => reject(e.target.error);
    });
  },

  async updateReading(reading) {
    return this.addReading(reading); // put() upserts
  },

  async deleteReading(id) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_READINGS, 'readwrite');
      tx.objectStore(STORE_READINGS).delete(id);
      tx.oncomplete = () => resolve(true);
      tx.onerror = (e) => reject(e.target.error);
    });
  },

  async getReading(id) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_READINGS, 'readonly');
      const req = tx.objectStore(STORE_READINGS).get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = (e) => reject(e.target.error);
    });
  },

  async getAllReadings() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_READINGS, 'readonly');
      const req = tx.objectStore(STORE_READINGS).getAll();
      req.onsuccess = () => {
        const rows = req.result || [];
        rows.sort((a, b) => new Date(b.readingDate) - new Date(a.readingDate));
        resolve(rows);
      };
      req.onerror = (e) => reject(e.target.error);
    });
  },

  async getLatestReading() {
    const rows = await this.getAllReadings();
    return rows.length ? rows[0] : null;
  },

  async clearReadings() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_READINGS, 'readwrite');
      tx.objectStore(STORE_READINGS).clear();
      tx.oncomplete = () => resolve(true);
      tx.onerror = (e) => reject(e.target.error);
    });
  },

  async bulkImportReadings(readings) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_READINGS, 'readwrite');
      const store = tx.objectStore(STORE_READINGS);
      readings.forEach((r) => {
        if (!r.id) r.id = uuid();
        store.put(r);
      });
      tx.oncomplete = () => resolve(true);
      tx.onerror = (e) => reject(e.target.error);
    });
  },

  // ---------- Settings ----------
  DEFAULT_SETTINGS: {
    theme: 'light',
    language: 'English',
    currency: 'INR',
    currencySymbol: '₹',
    defaultRate: 8.0,
    fixedCharge: 100,
    defaultTax: 5,
    defaultUnit: 'kWh',
    dateFormat: 'DD/MM/YYYY',
    numberFormat: '1,234.56',
  },

  async getSettings() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_SETTINGS, 'readonly');
      const req = tx.objectStore(STORE_SETTINGS).get('app');
      req.onsuccess = () => {
        resolve({ ...Storage.DEFAULT_SETTINGS, ...(req.result ? req.result.value : {}) });
      };
      req.onerror = (e) => reject(e.target.error);
    });
  },

  async saveSettings(settings) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_SETTINGS, 'readwrite');
      tx.objectStore(STORE_SETTINGS).put({ key: 'app', value: settings });
      tx.oncomplete = () => resolve(settings);
      tx.onerror = (e) => reject(e.target.error);
    });
  },

  async resetAll() {
    await this.clearReadings();
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_SETTINGS, 'readwrite');
      tx.objectStore(STORE_SETTINGS).clear();
      tx.oncomplete = () => resolve(true);
      tx.onerror = (e) => reject(e.target.error);
    });
  },

  uuid,
};
