/* WattWise — calculator.js
   Pure calculation functions for the billing engine. */

const Calculator = {
  calculate({ previousReading, currentReading, rate, fixedCharge = 0, taxPercent = 0 }) {
    const units = round2(currentReading - previousReading);
    const energyCharge = round2(units * rate);
    const taxAmount = round2(energyCharge * (taxPercent / 100));
    const totalBill = round2(energyCharge + fixedCharge + taxAmount);
    return { units, energyCharge, taxAmount, totalBill };
  },

  dailyAverage(units, daysBetween) {
    if (!daysBetween || daysBetween <= 0) return 0;
    return round2(units / daysBetween);
  },

  daysBetween(dateA, dateB) {
    const a = new Date(dateA);
    const b = new Date(dateB);
    const ms = Math.abs(b - a);
    return Math.max(1, Math.round(ms / 86400000));
  },

  percentChange(current, previous) {
    if (!previous) return 0;
    return round2(((current - previous) / previous) * 100);
  },
};

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

window.Calculator = Calculator;
