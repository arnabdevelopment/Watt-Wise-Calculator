/* WattWise — validation.js */

const Validation = {
  validateReadingForm({ previousReading, currentReading, readingDate, rate }) {
    const errors = {};

    if (previousReading === '' || previousReading === null || isNaN(previousReading)) {
      errors.previousReading = 'Previous reading is required.';
    } else if (Number(previousReading) < 0) {
      errors.previousReading = 'Must be a positive value.';
    }

    if (currentReading === '' || currentReading === null || isNaN(currentReading)) {
      errors.currentReading = 'Current reading is required.';
    } else if (Number(currentReading) < 0) {
      errors.currentReading = 'Must be a positive value.';
    } else if (!errors.previousReading && Number(currentReading) <= Number(previousReading)) {
      errors.currentReading = 'Must be greater than the previous reading.';
    }

    if (!readingDate) {
      errors.readingDate = 'Reading date is required.';
    } else {
      const d = new Date(readingDate);
      const today = new Date();
      today.setHours(23, 59, 59, 999);
      if (d > today) {
        errors.readingDate = 'Date cannot be in the future.';
      }
    }

    if (rate === '' || rate === null || isNaN(rate) || Number(rate) <= 0) {
      errors.rate = 'Rate must be greater than zero.';
    }

    return { valid: Object.keys(errors).length === 0, errors };
  },
};

window.Validation = Validation;
