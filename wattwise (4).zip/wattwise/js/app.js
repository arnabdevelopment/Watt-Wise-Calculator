/* WattWise — app.js
   App shell, bottom navigation, and page renderers. */

const App = {
  settings: null,
  formDraft: {},

  async init() {
    this.settings = await Storage.getSettings();
    UI.state.settings = this.settings;
    UI.applyTheme(this.settings.theme);

    this.renderShell();
    this.registerRoutes();
    Router.init();

    if ('serviceWorker' in navigator) {
      try { await navigator.serviceWorker.register('./service-worker.js'); } catch (e) { /* ignore */ }
    }
  },

  renderShell() {
    document.getElementById('app-root').innerHTML = `<div id="screen"></div>`;
    document.getElementById('bottom-nav-root').innerHTML = `
      <nav class="bottom-nav">
        <a class="nav-item" data-route="/dashboard" href="#/dashboard">
          ${navIconDashboard()}<span>Dashboard</span>
        </a>
        <a class="nav-item" data-route="/history" href="#/history">
          ${Icons.history}<span>History</span>
        </a>
        <a class="nav-item" data-route="/reports" href="#/reports">
          ${Icons.barChart}<span>Reports</span>
        </a>
        <a class="nav-item" data-route="/settings" href="#/settings">
          ${Icons.settings}<span>Settings</span>
        </a>
      </nav>`;
  },

  setScreen(html) {
    document.getElementById('screen').innerHTML = `<div class="screen">${html}</div>`;
  },

  registerRoutes() {
    Router.register('/dashboard', Pages.dashboard);
    Router.register('/history', Pages.history);
    Router.register('/reports', Pages.reports);
    Router.register('/settings', Pages.settings);
    Router.register('/reading/add', Pages.addReadingStep1);
    Router.register('/reading/step2', Pages.addReadingStep2);
    Router.register('/reading/summary', Pages.billSummary);
    Router.register('/reading/detail', Pages.readingDetail);
    Router.register('/reading/edit', Pages.editReading);
  },

  /**
   * Persist a patch of settings fields as a single atomic update.
   * Always merges against the in-memory App.settings (the freshest known
   * state) rather than re-reading the DB, so that firing two field updates
   * back-to-back (e.g. currency + currencySymbol) can never race and drop
   * one of them — which was the cause of "switching back to INR doesn't
   * stick".
   */
  async saveSettingsPatch(patch) {
    const merged = { ...App.settings, ...patch };
    App.settings = merged;
    UI.state.settings = merged;
    await Storage.saveSettings(merged);
    return merged;
  },

  async refreshSettings() {
    this.settings = await Storage.getSettings();
    UI.state.settings = this.settings;
    UI.applyTheme(this.settings.theme);
  },
};

function navIconDashboard() {
  return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1"></rect><rect x="14" y="3" width="7" height="5" rx="1"></rect><rect x="14" y="12" width="7" height="9" rx="1"></rect><rect x="3" y="16" width="7" height="5" rx="1"></rect></svg>`;
}

/* Reusable modern number-stepper markup. Pair with UI.wireStepper(). */
function numberStepperHTML(id, { value = 0, prefix = null, step = 1 } = {}) {
  const inputHTML = `<input class="stepper-input${prefix ? ' has-prefix' : ''}" id="${id}" type="number" inputmode="decimal" step="any" value="${value}">`;
  return `
    <div class="stepper" id="${id}-stepper">
      <button type="button" class="stepper-btn" data-step="dec" aria-label="Decrease" tabindex="-1">${Icons.minus}</button>
      ${prefix ? `<div class="stepper-prefix-wrap"><span class="prefix">${prefix}</span>${inputHTML}</div>` : inputHTML}
      <button type="button" class="stepper-btn" data-step="inc" aria-label="Increase" tabindex="-1">${Icons.plusSm}</button>
    </div>`;
}

/* ============================================================
   PAGES
   ============================================================ */
const Pages = {};

/* ---------------- Dashboard ---------------- */
Pages.dashboard = async () => {
  const settings = App.settings;
  const readings = await Storage.getAllReadings();
  const latest = readings[0] || null;
  const prev = readings[1] || null;

  const now = new Date();
  const dateInfo = UI.fmtDateLong(now);

  const currentUnits = latest ? latest.units : 0;
  const estimatedBill = latest ? latest.totalBill : 0;
  const unitsChangePct = prev ? Calculator.percentChange(latest.units, prev.units) : 0;

  const daysSpan = latest && prev ? Calculator.daysBetween(prev.readingDate, latest.readingDate) : (latest ? 30 : 0);
  const dailyAvg = latest ? Calculator.dailyAverage(latest.units, daysSpan || 30) : 0;
  const prevDailyAvg = prev && readings[2]
    ? Calculator.dailyAverage(prev.units, Calculator.daysBetween(readings[2].readingDate, prev.readingDate) || 30)
    : dailyAvg;
  const dailyAvgChangePct = prevDailyAvg ? Calculator.percentChange(dailyAvg, prevDailyAvg) : 0;

  const chartReadings = readings.slice(0, 10).slice().reverse();
  const chartData = chartReadings.map((r) => ({
    label: UI.fmtDate(r.readingDate).slice(0, 2) + ' ' + UI.fmtDate(r.readingDate).slice(3, 6).toUpperCase(),
    value: r.units,
    highlight: false,
  }));
  if (chartData.length) chartData[chartData.length - 1].highlight = true;

  const recent = readings.slice(0, 3);

  App.setScreen(`
    <div class="topbar">
      <div class="topbar-brand">${Icons.bolt} WattWise</div>
      <div class="topbar-actions">
        <button class="icon-btn" aria-label="Notifications">${Icons.bell}</button>
        <div class="avatar">${Icons.bolt}</div>
      </div>
    </div>
    <div class="container" style="padding-top:4px;">
      <div class="dashboard-greeting-row">
        <div class="dashboard-greeting">
          <h2>Good ${greetingWord()} 👋</h2>
          <p>Track your electricity usage and bill.</p>
        </div>
        <div class="dashboard-date">${dateInfo.full}<span class="dow">${dateInfo.dow}</span></div>
      </div>

      <div class="card-grid">
        <div class="stat-card">
          <div class="stat-top">
            <div class="stat-icon">${Icons.bolt}</div>
            ${latest ? trendBadge(unitsChangePct) : ''}
          </div>
          <div class="stat-label">Current Units</div>
          <div class="stat-value">${UI.fmtUnits(currentUnits)} <span class="unit">kWh</span></div>
        </div>
        <div class="stat-card accent">
          <div class="stat-top">
            <div class="stat-icon">${Icons.cashCoin}</div>
            <span class="stat-badge">TODAY</span>
          </div>
          <div class="stat-label">Estimated Bill</div>
          <div class="stat-value">${UI.fmtMoney(estimatedBill, settings)}</div>
        </div>
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon">${Icons.calendar}</div></div>
          <div class="stat-label">Last Reading</div>
          <div class="stat-value" style="font-size:16px;">${latest ? UI.fmtDate(latest.readingDate) : '—'}</div>
        </div>
        <div class="stat-card">
          <div class="stat-top">
            <div class="stat-icon">${Icons.gauge}</div>
            ${latest ? trendBadge(dailyAvgChangePct) : ''}
          </div>
          <div class="stat-label">Daily Avg</div>
          <div class="stat-value">${UI.fmtUnits(dailyAvg)} <span class="unit">kWh</span></div>
        </div>
      </div>

      <div class="section-title">Quick Actions</div>
      <div class="quick-actions">
        <a class="quick-action primary" href="#/reading/add">
          <div class="qa-icon">${Icons.plus}</div><span>Add Reading</span>
        </a>
        <a class="quick-action" href="#/history">
          <div class="qa-icon">${Icons.history}</div><span>History</span>
        </a>
        <a class="quick-action" href="#/reports">
          <div class="qa-icon">${Icons.barChart}</div><span>Reports</span>
        </a>
        <a class="quick-action" href="#/reports">
          <div class="qa-icon">${Icons.receipt}</div><span>Bills</span>
        </a>
      </div>

      <div class="chart-card" style="margin-top:26px;">
        <div class="chart-title">
          <span>Electricity Usage</span>
          <span class="stat-badge up" style="background:var(--color-primary-light);color:var(--color-primary);">Recent Readings</span>
        </div>
        <div class="usage-chart-wrap">
          <canvas id="usage-chart"></canvas>
        </div>
      </div>

      <div class="section-title">Recent Readings <a class="link" href="#/history">View All</a></div>
      ${recent.length ? recent.map(readingRowHTML).join('') : emptyStateHTML('No readings yet', 'Add your first meter reading to get started.')}
    </div>
    <a class="fab" href="#/reading/add" aria-label="Add reading">${Icons.plus}</a>
  `);

  const canvas = document.getElementById('usage-chart');
  if (canvas && chartData.length) {
    Charts.bar(canvas, chartData, { height: 170 });
  }
};

function greetingWord() {
  const h = new Date().getHours();
  if (h < 12) return 'Morning';
  if (h < 17) return 'Afternoon';
  return 'Evening';
}

function sameMonth(a, b) {
  return a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear();
}

function trendBadge(pct) {
  const up = pct >= 0;
  return `<span class="stat-badge ${up ? 'up' : 'down'}">${up ? Icons.trendUp : Icons.trendDown} ${Math.abs(pct).toFixed(0)}%</span>`;
}

function readingRowHTML(r) {
  return `
    <a class="reading-row" href="#/reading/detail?id=${r.id}">
      <div class="r-icon">${Icons.bolt}</div>
      <div class="r-body">
        <div class="r-date">${UI.fmtDate(r.readingDate)}</div>
        <div class="r-sub">${UI.fmtUnits(r.units)} Units • ${UI.fmtMoney(r.totalBill)}</div>
      </div>
      <div class="r-chev">${Icons.chevronRight}</div>
    </a>`;
}

function emptyStateHTML(title, sub) {
  return `
    <div class="empty-state">
      <div class="es-icon">${Icons.bolt}</div>
      <h3>${title}</h3>
      <p>${sub}</p>
    </div>`;
}

function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

/* ---------------- Add Reading — Step 1: Meter Details ---------------- */
Pages.addReadingStep1 = async () => {
  const latest = await Storage.getLatestReading();
  const editId = App.formDraft.editId || null;

  const draft = App.formDraft.data || {
    previousReading: latest ? latest.currentReading : '',
    currentReading: '',
    readingDate: UI.toISODateInputValue(new Date()),
  };

  App.setScreen(`
    <div class="page-header">
      <a class="back-btn" href="#/dashboard">${Icons.arrowLeft}</a>
      <h1>${editId ? 'Edit Meter Reading' : 'Add Meter Reading'}</h1>
    </div>
    <div class="container">
      <span class="step-badge">Step 1 of 2</span>
      <div class="step-progress"><div class="step-progress-fill" style="width:50%;"></div></div>
      <h2 style="font-size:19px;margin-bottom:6px;">Enter Meter Details</h2>
      <p style="color:var(--color-text-muted);font-size:13.5px;margin-bottom:22px;">Fill in the details below to calculate your electricity bill.</p>

      <form id="step1-form">
        <div class="card form-card">
          <div class="form-card-header"><div class="fch-icon blue">${Icons.gauge}</div>Reading Details</div>

          <div class="field-group">
            <label class="field-label" for="previousReading">Previous Meter Reading</label>
            <input class="input" id="previousReading" type="number" step="any" inputmode="decimal" placeholder="e.g. 12540" value="${draft.previousReading}">
            <div class="field-error" id="err-previousReading"></div>
          </div>

          <div class="field-group">
            <label class="field-label" for="currentReading">Current Meter Reading</label>
            <input class="input" id="currentReading" type="number" step="any" inputmode="decimal" placeholder="e.g. 12710" value="${draft.currentReading}">
            <div class="field-error" id="err-currentReading"></div>
          </div>

          <div class="field-group" style="margin-bottom:0;">
            <label class="field-label" for="readingDate">Reading Date</label>
            <input class="input" id="readingDate" type="date" value="${draft.readingDate}" max="${UI.toISODateInputValue(new Date())}">
            <div class="field-error" id="err-readingDate"></div>
          </div>
        </div>

        <button type="submit" class="btn btn-primary">Continue</button>
      </form>
    </div>
  `);

  document.getElementById('step1-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const previousReading = document.getElementById('previousReading').value;
    const currentReading = document.getElementById('currentReading').value;
    const readingDate = document.getElementById('readingDate').value;

    ['previousReading', 'currentReading', 'readingDate'].forEach((f) => {
      document.getElementById(f).classList.remove('has-error');
      document.getElementById('err-' + f).textContent = '';
    });

    const { errors } = Validation.validateReadingForm({ previousReading, currentReading, readingDate, rate: 1 });
    delete errors.rate;

    if (Object.keys(errors).length) {
      Object.entries(errors).forEach(([field, msg]) => {
        document.getElementById(field).classList.add('has-error');
        document.getElementById('err-' + field).textContent = msg;
      });
      return;
    }

    App.formDraft.data = {
      ...(App.formDraft.data || {}),
      previousReading: Number(previousReading),
      currentReading: Number(currentReading),
      readingDate,
    };
    Router.navigate('/reading/step2');
  });
};

/* ---------------- Add Reading — Step 2: Billing Rates ---------------- */
Pages.addReadingStep2 = async () => {
  const settings = App.settings;
  const draft = App.formDraft.data;
  if (!draft) { Router.navigate('/reading/add'); return; }

  const rate = draft.rate ?? settings.defaultRate;
  const fixedCharge = draft.fixedCharge ?? settings.fixedCharge;
  const taxPercent = draft.taxPercent ?? settings.defaultTax;
  const notes = draft.notes ?? '';

  App.setScreen(`
    <div class="page-header">
      <a class="back-btn" href="#/reading/add">${Icons.arrowLeft}</a>
      <h1>Add Meter Reading</h1>
    </div>
    <div class="container">
      <span class="step-badge">Step 2 of 2</span>
      <div class="step-progress"><div class="step-progress-fill" style="width:100%;"></div></div>
      <h2 style="font-size:19px;margin-bottom:6px;">Billing Rates</h2>
      <p style="color:var(--color-text-muted);font-size:13.5px;margin-bottom:22px;">Set your tariff to calculate the final bill.</p>

      <form id="step2-form">
        <div class="card form-card">
          <div class="form-card-header"><div class="fch-icon green">${Icons.cashCoin}</div>Billing Rates</div>

          <div class="two-col">
            <div class="field-group">
              <label class="field-label" for="rate">Rate per Unit</label>
              ${numberStepperHTML('rate', { value: rate, prefix: settings.currencySymbol, step: 0.5 })}
              <div class="field-error" id="err-rate"></div>
            </div>
            <div class="field-group">
              <label class="field-label" for="taxPercent">Tax (%)</label>
              ${numberStepperHTML('taxPercent', { value: taxPercent, step: 1 })}
            </div>
          </div>

          <div class="field-group" style="margin-bottom:0;">
            <label class="field-label" for="fixedCharge">Fixed Charge</label>
            ${numberStepperHTML('fixedCharge', { value: fixedCharge, prefix: settings.currencySymbol, step: 10 })}
            <div class="field-hint">Monthly service charge applied globally</div>
          </div>
        </div>

        <div class="field-group">
          <label class="field-label" for="notes">Additional Notes</label>
          <textarea class="textarea" id="notes" rows="3" placeholder="Add notes (optional)...">${notes}</textarea>
        </div>

        <div class="summary-box" id="live-summary"></div>

        <button type="submit" class="btn btn-primary">${Icons.bolt} Calculate &amp; Save</button>
        <div style="height:10px;"></div>
        <button type="button" id="clear-form-btn" class="btn btn-outline">Clear Form</button>
      </form>
    </div>
  `);

  UI.wireStepper(document.getElementById('rate-stepper'), { min: 0, step: 0.5, onChange: recompute });
  UI.wireStepper(document.getElementById('taxPercent-stepper'), { min: 0, max: 100, step: 1, onChange: recompute });
  UI.wireStepper(document.getElementById('fixedCharge-stepper'), { min: 0, step: 10, onChange: recompute });

  function recompute() {
    const r = parseFloat(document.getElementById('rate').value) || 0;
    const t = parseFloat(document.getElementById('taxPercent').value) || 0;
    const f = parseFloat(document.getElementById('fixedCharge').value) || 0;
    const result = Calculator.calculate({
      previousReading: draft.previousReading,
      currentReading: draft.currentReading,
      rate: r, fixedCharge: f, taxPercent: t,
    });
    document.getElementById('live-summary').innerHTML = `
      <div class="sb-label">Estimated Summary</div>
      <div class="sb-row"><span>Units Consumed</span><span>${UI.fmtUnits(result.units)} kWh</span></div>
      <div class="sb-row"><span>Energy Charge</span><span>${UI.fmtMoneyPrecise(result.energyCharge)}</span></div>
      <div class="sb-row"><span>Fixed + Tax</span><span>${UI.fmtMoneyPrecise(f + result.taxAmount)}</span></div>
      <div class="sb-row total"><span>Total Bill</span><span>${UI.fmtMoneyPrecise(result.totalBill)}</span></div>
    `;
    return result;
  }
  recompute();
  ['rate', 'taxPercent', 'fixedCharge'].forEach((id) => {
    document.getElementById(id).addEventListener('input', recompute);
  });

  document.getElementById('clear-form-btn').addEventListener('click', () => {
    document.getElementById('rate').value = settings.defaultRate;
    document.getElementById('taxPercent').value = settings.defaultTax;
    document.getElementById('fixedCharge').value = settings.fixedCharge;
    document.getElementById('notes').value = '';
    recompute();
  });

  document.getElementById('step2-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const rateVal = document.getElementById('rate').value;
    const { errors } = Validation.validateReadingForm({
      previousReading: draft.previousReading,
      currentReading: draft.currentReading,
      readingDate: draft.readingDate,
      rate: rateVal,
    });
    document.getElementById('rate-stepper').classList.remove('has-error');
    document.getElementById('err-rate').textContent = '';
    if (errors.rate) {
      document.getElementById('rate-stepper').classList.add('has-error');
      document.getElementById('err-rate').textContent = errors.rate;
      return;
    }

    const result = recompute();
    const reading = {
      id: App.formDraft.editId || undefined,
      previousReading: draft.previousReading,
      currentReading: draft.currentReading,
      units: result.units,
      rate: parseFloat(rateVal),
      fixedCharge: parseFloat(document.getElementById('fixedCharge').value) || 0,
      taxPercent: parseFloat(document.getElementById('taxPercent').value) || 0,
      energyCharge: result.energyCharge,
      taxAmount: result.taxAmount,
      totalBill: result.totalBill,
      readingDate: draft.readingDate,
      notes: document.getElementById('notes').value.trim(),
    };

    await Storage.addReading(reading);
    App.formDraft.savedId = reading.id;
    App.formDraft.data = null;
    App.formDraft.editId = null;
    UI.toast(App.formDraft.wasEdit ? 'Reading updated' : 'Reading saved', 'success');
    App.formDraft.wasEdit = false;
    Router.navigate('/reading/summary');
  });
};

/* ---------------- Bill Summary (result screen) ---------------- */
Pages.billSummary = async (params) => {
  const id = params.get('id') || App.formDraft.savedId;
  const r = await Storage.getReading(id);
  if (!r) { Router.navigate('/dashboard'); return; }

  const settings = App.settings;
  const prevAll = (await Storage.getAllReadings()).filter((x) => x.id !== r.id && new Date(x.readingDate) < new Date(r.readingDate));
  const prev = prevAll[0];
  const pctChange = prev ? Calculator.percentChange(r.totalBill, prev.totalBill) : 0;
  const days = prev ? Calculator.daysBetween(prev.readingDate, r.readingDate) : 30;
  const dailyAvg = Calculator.dailyAverage(r.units, days);
  const dailyCost = days ? round2(r.totalBill / days) : r.totalBill;

  const periodStart = prev ? UI.fmtDate(prev.readingDate) : '—';
  const periodEnd = UI.fmtDate(r.readingDate);

  App.setScreen(`
    <div class="page-header">
      <div class="topbar-brand" style="font-size:17px;">${Icons.bolt} Bill Summary</div>
      <div style="margin-left:auto;"><button class="icon-btn">${Icons.bell}</button></div>
    </div>

    <div class="result-hero">
      <div class="result-icon-circle">${Icons.bolt}</div>
      <h2>Bill Calculated Successfully</h2>
      <p>Your electricity bill has been calculated and saved locally to your device.</p>
    </div>

    <div class="bill-hero-card">
      <span class="bh-badge">${new Date(r.readingDate).getFullYear()}</span>
      <div class="bh-label">Estimated Bill</div>
      <div class="bh-amount">${UI.fmtMoney(r.totalBill, settings)}</div>
      <div class="bh-period">Billing Period: ${periodStart} – ${periodEnd}</div>
    </div>

    <div class="container" style="padding-top:0;">
      <div class="section-title" style="margin-top:6px;">Meter Details</div>
      <div class="card">
        <div class="detail-list">
          <div class="detail-row"><span class="dr-label">Previous Reading</span><span class="dr-value">${UI.fmtUnits(r.previousReading)}<span class="unit-tag">kWh</span></span></div>
          <div class="detail-row"><span class="dr-label">Current Reading</span><span class="dr-value">${UI.fmtUnits(r.currentReading)}<span class="unit-tag">kWh</span></span></div>
          <div class="detail-row"><span class="dr-label">Units Consumed</span><span class="dr-value" style="color:var(--color-primary);">${UI.fmtUnits(r.units)}<span class="unit-tag">kWh</span></span></div>
          <div class="detail-row"><span class="dr-label">Reading Date</span><span class="dr-value">${UI.fmtDate(r.readingDate)}</span></div>
        </div>
      </div>

      <div class="section-title">Bill Breakdown</div>
      <div class="card">
        <div class="detail-list">
          <div class="detail-row"><span class="dr-label">Energy Charge</span><span class="dr-value">${UI.fmtMoney(r.energyCharge, settings)}</span></div>
          <div class="detail-row"><span class="dr-label">Fixed Charge</span><span class="dr-value">${UI.fmtMoney(r.fixedCharge, settings)}</span></div>
          <div class="detail-row"><span class="dr-label">Tax (${r.taxPercent}%)</span><span class="dr-value">${UI.fmtMoney(r.taxAmount, settings)}</span></div>
          <div class="detail-row total"><span class="dr-label">Total Bill</span><span class="dr-value">${UI.fmtMoney(r.totalBill, settings)}</span></div>
        </div>
      </div>

      <div class="section-title">Smart Insights</div>
      <div class="insight-row">
        <div class="ir-icon blue">${Icons.gauge}</div>
        <div><div class="ir-label">Avg Daily Usage</div><div class="ir-value">${UI.fmtUnits(dailyAvg)} kWh</div></div>
      </div>
      <div class="insight-row">
        <div class="ir-icon green">${Icons.cashCoin}</div>
        <div><div class="ir-label">Daily Cost</div><div class="ir-value">${UI.fmtMoney(dailyCost, settings)}/day</div></div>
      </div>
      ${prev ? `
      <div class="insight-row">
        <div class="ir-icon ${pctChange >= 0 ? 'red' : 'green'}">${pctChange >= 0 ? Icons.trendUp : Icons.trendDown}</div>
        <div><div class="ir-label">Comparison</div><div class="ir-value ${pctChange >= 0 ? 'danger' : ''}">${Math.abs(pctChange).toFixed(0)}% ${pctChange >= 0 ? 'higher' : 'lower'} than last reading</div></div>
      </div>` : ''}

      <div style="height:6px;"></div>
      <button class="btn btn-primary" id="done-btn">Done</button>
      <div style="height:10px;"></div>
      <button class="btn btn-outline" id="edit-btn">Edit Reading</button>
      <div style="text-align:center;margin-top:14px;">
        <a class="btn-text" href="#/reading/add" style="display:inline-block;width:auto;">Calculate Another Bill</a>
      </div>
    </div>
  `);

  document.getElementById('done-btn').addEventListener('click', () => Router.navigate('/dashboard'));
  document.getElementById('edit-btn').addEventListener('click', () => {
    App.formDraft.editId = r.id;
    App.formDraft.wasEdit = true;
    App.formDraft.data = {
      previousReading: r.previousReading,
      currentReading: r.currentReading,
      readingDate: r.readingDate,
      rate: r.rate,
      fixedCharge: r.fixedCharge,
      taxPercent: r.taxPercent,
      notes: r.notes,
    };
    Router.navigate('/reading/add');
  });
};

/* ---------------- History ---------------- */
Pages._historyState = { search: '', filter: 'all' };

Pages.history = async () => {
  const settings = App.settings;
  const all = await Storage.getAllReadings();
  const totalUnits = all.reduce((a, r) => a + r.units, 0);

  App.setScreen(`
    <div class="page-header">
      <a class="back-btn" href="#/dashboard">${Icons.arrowLeft}</a>
      <h1>Reading History</h1>
    </div>
    <div class="container" style="padding-top:0;">
      <div class="history-stats">
        <div class="stat-card"><div class="stat-label">Total Readings</div><div class="stat-value">${all.length}</div></div>
        <div class="stat-card"><div class="stat-label">Total Units</div><div class="stat-value">${UI.fmtUnits(totalUnits)} <span class="unit">kWh</span></div></div>
      </div>

      <div class="search-wrap">
        <span class="search-icon">${Icons.search}</span>
        <input class="input" id="history-search" placeholder="Search by date, notes, or reading..." value="${Pages._historyState.search}">
      </div>

      <div class="filter-pills" id="filter-pills">
        ${['all','thisMonth','lastMonth','last3','last6'].map(f => `
          <button class="filter-pill ${Pages._historyState.filter === f ? 'active' : ''}" data-filter="${f}">${filterLabel(f)}</button>
        `).join('')}
      </div>

      <div id="history-list"></div>
    </div>
    <a class="fab" href="#/reading/add" aria-label="Add reading">${Icons.plus}</a>
  `);

  function renderList() {
    let rows = all.slice();
    const { search, filter } = Pages._historyState;

    const now = new Date();
    if (filter === 'thisMonth') rows = rows.filter(r => sameMonth(new Date(r.readingDate), now));
    if (filter === 'lastMonth') {
      const lm = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      rows = rows.filter(r => sameMonth(new Date(r.readingDate), lm));
    }
    if (filter === 'last3') {
      const cutoff = new Date(); cutoff.setMonth(cutoff.getMonth() - 3);
      rows = rows.filter(r => new Date(r.readingDate) >= cutoff);
    }
    if (filter === 'last6') {
      const cutoff = new Date(); cutoff.setMonth(cutoff.getMonth() - 6);
      rows = rows.filter(r => new Date(r.readingDate) >= cutoff);
    }

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      rows = rows.filter(r =>
        UI.fmtDate(r.readingDate).toLowerCase().includes(q) ||
        (r.notes || '').toLowerCase().includes(q) ||
        String(r.currentReading).includes(q) ||
        String(r.previousReading).includes(q)
      );
    }

    const listEl = document.getElementById('history-list');
    if (!rows.length) {
      listEl.innerHTML = emptyStateHTML('No readings found', 'Try a different search or filter, or add a new reading.');
      return;
    }

    listEl.innerHTML = rows.map((r) => {
      const isLatest = all[0] && r.id === all[0].id;
      const avgRate = r.units ? round2(r.totalBill / r.units) : 0;
      return `
      <div class="history-card ${isLatest ? 'latest' : ''}">
        <div class="hc-top">
          <div style="display:flex;align-items:center;gap:8px;">
            ${isLatest ? '<span class="hc-badge">Latest</span>' : ''}
            <span class="hc-date">${UI.fmtDate(r.readingDate)}</span>
          </div>
          <div class="hc-actions">
            <button data-view="${r.id}" aria-label="View">${Icons.eye}</button>
            <button data-edit="${r.id}" aria-label="Edit">${Icons.edit}</button>
            <button data-delete="${r.id}" class="danger" aria-label="Delete">${Icons.trash}</button>
          </div>
        </div>
        <div class="hc-grid">
          <div><div class="label">Prev Reading</div><div class="value">${UI.fmtUnits(r.previousReading)}</div></div>
          <div><div class="label">Curr Reading</div><div class="value">${UI.fmtUnits(r.currentReading)}</div></div>
          <div><div class="label">Units Used</div><div class="value blue">${UI.fmtUnits(r.units)} kWh</div></div>
          <div><div class="label">Bill Amount</div><div class="value green">${UI.fmtMoney(r.totalBill, settings)}</div></div>
        </div>
        <div class="hc-rate">Avg Rate: ${settings.currencySymbol}${avgRate.toFixed(2)}/kWh</div>
        ${r.notes ? `<div class="hc-note">"${escapeHTML(r.notes)}"</div>` : ''}
      </div>`;
    }).join('');

    listEl.querySelectorAll('[data-view]').forEach(btn => btn.addEventListener('click', () => Router.navigate('/reading/detail?id=' + btn.dataset.view)));
    listEl.querySelectorAll('[data-edit]').forEach(btn => btn.addEventListener('click', () => startEditFromId(btn.dataset.edit)));
    listEl.querySelectorAll('[data-delete]').forEach(btn => btn.addEventListener('click', () => confirmDeleteReading(btn.dataset.delete, renderList, all)));
  }

  renderList();

  document.getElementById('history-search').addEventListener('input', (e) => {
    Pages._historyState.search = e.target.value;
    renderList();
  });
  document.getElementById('filter-pills').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-filter]');
    if (!btn) return;
    Pages._historyState.filter = btn.dataset.filter;
    document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    renderList();
  });
};

function filterLabel(f) {
  return { all: 'All', thisMonth: 'This Month', lastMonth: 'Last Month', last3: 'Last 3mo', last6: 'Last 6mo' }[f];
}

function escapeHTML(s) {
  return s.replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

async function startEditFromId(id) {
  const r = await Storage.getReading(id);
  if (!r) return;
  App.formDraft.editId = r.id;
  App.formDraft.wasEdit = true;
  App.formDraft.data = {
    previousReading: r.previousReading,
    currentReading: r.currentReading,
    readingDate: r.readingDate,
    rate: r.rate,
    fixedCharge: r.fixedCharge,
    taxPercent: r.taxPercent,
    notes: r.notes,
  };
  Router.navigate('/reading/add');
}

function confirmDeleteReading(id, onDone, cachedAll) {
  UI.showModal({
    title: 'Delete this reading?',
    text: 'This will permanently remove the reading and its bill from your device. This cannot be undone.',
    confirmLabel: 'Delete',
    danger: true,
    onConfirm: async () => {
      await Storage.deleteReading(id);
      const idx = cachedAll.findIndex(r => r.id === id);
      if (idx > -1) cachedAll.splice(idx, 1);
      UI.toast('Reading deleted', 'success');
      onDone();
    },
  });
}

/* Reused by history edit buttons */
Pages.editReading = Pages.addReadingStep1;

/* ---------------- Reading Detail ---------------- */
Pages.readingDetail = async (params) => {
  const id = params.get('id');
  const r = await Storage.getReading(id);
  if (!r) { Router.navigate('/history'); return; }
  const settings = App.settings;

  App.setScreen(`
    <div class="page-header">
      <a class="back-btn" href="#/history">${Icons.arrowLeft}</a>
      <h1>Reading Details</h1>
    </div>
    <div class="bill-hero-card" style="margin-top:8px;">
      <div class="bh-label">Total Bill</div>
      <div class="bh-amount">${UI.fmtMoney(r.totalBill, settings)}</div>
      <div class="bh-period">${UI.fmtDate(r.readingDate)}</div>
    </div>
    <div class="container" style="padding-top:0;">
      <div class="card">
        <div class="detail-list">
          <div class="detail-row"><span class="dr-label">Previous Reading</span><span class="dr-value">${UI.fmtUnits(r.previousReading)}<span class="unit-tag">kWh</span></span></div>
          <div class="detail-row"><span class="dr-label">Current Reading</span><span class="dr-value">${UI.fmtUnits(r.currentReading)}<span class="unit-tag">kWh</span></span></div>
          <div class="detail-row"><span class="dr-label">Units Used</span><span class="dr-value">${UI.fmtUnits(r.units)}<span class="unit-tag">kWh</span></span></div>
          <div class="detail-row"><span class="dr-label">Rate</span><span class="dr-value">${settings.currencySymbol}${r.rate}/kWh</span></div>
          <div class="detail-row"><span class="dr-label">Energy Charge</span><span class="dr-value">${UI.fmtMoney(r.energyCharge, settings)}</span></div>
          <div class="detail-row"><span class="dr-label">Fixed Charge</span><span class="dr-value">${UI.fmtMoney(r.fixedCharge, settings)}</span></div>
          <div class="detail-row"><span class="dr-label">Tax (${r.taxPercent}%)</span><span class="dr-value">${UI.fmtMoney(r.taxAmount, settings)}</span></div>
          <div class="detail-row total"><span class="dr-label">Total Bill</span><span class="dr-value">${UI.fmtMoney(r.totalBill, settings)}</span></div>
        </div>
        ${r.notes ? `<div class="hc-note" style="margin-top:8px;">"${escapeHTML(r.notes)}"</div>` : ''}
      </div>
      <div class="bill-detail-actions">
        <button class="btn btn-outline" id="edit-detail-btn">${Icons.edit} Edit</button>
        <button class="btn btn-danger-outline" id="delete-detail-btn">${Icons.trash} Delete</button>
      </div>
    </div>
  `);

  document.getElementById('edit-detail-btn').addEventListener('click', () => startEditFromId(r.id));
  document.getElementById('delete-detail-btn').addEventListener('click', () => {
    UI.showModal({
      title: 'Delete this reading?',
      text: 'This will permanently remove the reading and its bill from your device. This cannot be undone.',
      confirmLabel: 'Delete',
      danger: true,
      onConfirm: async () => {
        await Storage.deleteReading(r.id);
        UI.toast('Reading deleted', 'success');
        Router.navigate('/history');
      },
    });
  });
};

/* ---------------- Reports ---------------- */
Pages._reportsState = { range: 'month' };

Pages.reports = async () => {
  const settings = App.settings;
  const all = await Storage.getAllReadings(); // newest first

  App.setScreen(`
    <div class="page-header">
      <div class="topbar-brand" style="font-size:17px;">${Icons.bolt} Reports &amp; Analytics</div>
    </div>
    <div class="container" style="padding-top:0;">
      <div class="tab-pills" id="range-pills">
        ${[['month','This Month'],['last','Last Month'],['q3','3 Months'],['year','This Year']].map(([k,l]) => `
          <div class="tab-pill ${Pages._reportsState.range === k ? 'active' : ''}" data-range="${k}">${l}</div>
        `).join('')}
      </div>
      <div id="reports-body"></div>
    </div>
  `);

  function rangeFilter(rows) {
    const now = new Date();
    const range = Pages._reportsState.range;
    if (range === 'month') return rows.filter(r => sameMonth(new Date(r.readingDate), now));
    if (range === 'last') {
      const lm = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      return rows.filter(r => sameMonth(new Date(r.readingDate), lm));
    }
    if (range === 'q3') {
      const cutoff = new Date(); cutoff.setMonth(cutoff.getMonth() - 3);
      return rows.filter(r => new Date(r.readingDate) >= cutoff);
    }
    if (range === 'year') return rows.filter(r => new Date(r.readingDate).getFullYear() === now.getFullYear());
    return rows;
  }

  let currentRows = [];
  let currentRangeLabel = '';

  function renderBody() {
    const rows = rangeFilter(all).slice().sort((a,b) => new Date(a.readingDate) - new Date(b.readingDate));
    currentRows = rows;
    currentRangeLabel = { month: 'This Month', last: 'Last Month', q3: 'Last 3 Months', year: 'This Year' }[Pages._reportsState.range];
    const body = document.getElementById('reports-body');

    if (!rows.length) {
      body.innerHTML = emptyStateHTML('Not enough data yet', 'Add a few readings to see reports and trends here.');
      return;
    }

    const totalUnits = rows.reduce((a, r) => a + r.units, 0);
    const totalCost = rows.reduce((a, r) => a + r.totalBill, 0);
    const highest = rows.reduce((a, r) => (r.units > a.units ? r : a), rows[0]);
    const lowest = rows.reduce((a, r) => (r.units < a.units ? r : a), rows[0]);
    const totalEnergy = rows.reduce((a, r) => a + r.energyCharge, 0);
    const totalFixed = rows.reduce((a, r) => a + r.fixedCharge, 0);
    const totalTax = rows.reduce((a, r) => a + r.taxAmount, 0);
    const costTotal = totalEnergy + totalFixed + totalTax || 1;

    const priorAll = all.filter(r => !rows.includes(r));
    const priorUnits = priorAll.slice(0, rows.length).reduce((a, r) => a + r.units, 0);
    const unitsChangePct = priorUnits ? Calculator.percentChange(totalUnits, priorUnits) : 0;

    const usageChartData = rows.map(r => ({ label: UI.fmtDate(r.readingDate).slice(0,6), value: r.units }));

    const donutSegments = [
      { label: 'Energy', value: totalEnergy, color: '#2563EB' },
      { label: 'Fixed', value: totalFixed, color: '#F59E0B' },
      { label: 'Tax', value: totalTax, color: '#0F172A' },
    ];

    body.innerHTML = `
      <div class="card-grid">
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon">${Icons.bolt}</div>${priorAll.length ? trendBadge(unitsChangePct) : ''}</div>
          <div class="stat-label">Total Units</div>
          <div class="stat-value">${UI.fmtUnits(totalUnits)} <span class="unit">kWh</span></div>
        </div>
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon">${Icons.cashCoin}</div></div>
          <div class="stat-label">Total Cost</div>
          <div class="stat-value">${UI.fmtMoney(totalCost, settings)}</div>
        </div>
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon">${Icons.gauge}</div></div>
          <div class="stat-label">Avg / Reading</div>
          <div class="stat-value">${UI.fmtUnits(totalUnits / rows.length)} <span class="unit">kWh</span></div>
        </div>
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon">${Icons.receipt}</div></div>
          <div class="stat-label">Readings</div>
          <div class="stat-value">${rows.length}</div>
        </div>
      </div>

      <div class="chart-card" style="margin-top:20px;">
        <div class="chart-title"><span>Electricity Usage</span><span style="font-size:12px;color:var(--color-text-muted);">kWh / reading</span></div>
        <div class="usage-chart-wrap"><canvas id="report-usage-chart"></canvas></div>
      </div>

      <div class="chart-card">
        <div class="chart-title"><span>Cost Composition</span></div>
        <div style="display:flex;justify-content:center;"><canvas id="report-donut-chart" width="170" height="170"></canvas></div>
        <div class="legend-row">
          ${donutSegments.map(s => `<div class="legend-item"><span class="legend-dot" style="background:${s.color};"></span>${s.label} (${Math.round(s.value/costTotal*100)}%)</div>`).join('')}
        </div>
      </div>

      <div class="section-title" style="margin-top:6px;">Consumption Extremes</div>
      <div class="extremes-grid">
        <div class="extreme-card high">
          <div class="ex-label">${Icons.trendUp} Highest</div>
          <div class="ex-value">${UI.fmtUnits(highest.units)} kWh</div>
          <div class="ex-date">${UI.fmtDate(highest.readingDate)}</div>
        </div>
        <div class="extreme-card low">
          <div class="ex-label">${Icons.trendDown} Lowest</div>
          <div class="ex-value">${UI.fmtUnits(lowest.units)} kWh</div>
          <div class="ex-date">${UI.fmtDate(lowest.readingDate)}</div>
        </div>
      </div>

      <div class="section-title">Cost Breakdown</div>
      <div class="card">
        <div class="cost-breakdown-bar">
          <div style="width:${Math.round(totalEnergy/costTotal*100)}%;background:#2563EB;"></div>
          <div style="width:${Math.round(totalFixed/costTotal*100)}%;background:#F59E0B;"></div>
          <div style="width:${Math.round(totalTax/costTotal*100)}%;background:#0F172A;"></div>
        </div>
        <div class="legend-row" style="margin-top:0;">
          <div class="legend-item"><span class="legend-dot" style="background:#2563EB;"></span>Energy: ${UI.fmtMoney(totalEnergy, settings)}</div>
          <div class="legend-item"><span class="legend-dot" style="background:#F59E0B;"></span>Fixed: ${UI.fmtMoney(totalFixed, settings)}</div>
          <div class="legend-item"><span class="legend-dot" style="background:#0F172A;"></span>Tax: ${UI.fmtMoney(totalTax, settings)}</div>
        </div>
      </div>

      <div class="section-title">Smart Insights</div>
      ${priorAll.length ? `
      <div class="insight-row">
        <div class="ir-icon ${unitsChangePct >= 0 ? 'red' : 'green'}">${unitsChangePct >= 0 ? Icons.trendUp : Icons.trendDown}</div>
        <div><div class="ir-label">Usage ${unitsChangePct >= 0 ? 'increased' : 'decreased'} by ${Math.abs(unitsChangePct).toFixed(0)}%</div><div class="ir-value" style="font-weight:400;font-size:12.5px;color:var(--color-text-muted);">Compared with the previous period of the same length.</div></div>
      </div>` : ''}
      <div class="insight-row">
        <div class="ir-icon green">${Icons.lightbulb}</div>
        <div><div class="ir-label">Potential Savings</div><div class="ir-value" style="font-weight:400;font-size:12.5px;color:var(--color-text-muted);">Trimming daily use by 1 kWh could save roughly ${UI.fmtMoney((rows[rows.length-1]?.rate || settings.defaultRate) * 30, settings)}/month.</div></div>
      </div>

      <div class="two-col" style="margin-top:20px;">
        <button class="btn btn-outline" id="export-pdf-btn">${Icons.fileText} Export PDF</button>
        <button class="btn btn-outline" id="export-csv-btn">${Icons.download} Export CSV</button>
      </div>
    `;

    const uc = document.getElementById('report-usage-chart');
    if (uc) Charts.area(uc, usageChartData, { height: 170 });
    const dc = document.getElementById('report-donut-chart');
    if (dc) Charts.donut(dc, donutSegments, { size: 170, centerLabel: UI.fmtMoney(costTotal, settings), centerSubLabel: 'Total' });

    document.getElementById('export-pdf-btn')?.addEventListener('click', () => exportPDF(rows, currentRangeLabel, settings));
    document.getElementById('export-csv-btn')?.addEventListener('click', () => exportCSV(rows));
  }

  renderBody();
  document.getElementById('range-pills').addEventListener('click', (e) => {
    const el = e.target.closest('[data-range]');
    if (!el) return;
    Pages._reportsState.range = el.dataset.range;
    document.querySelectorAll('.tab-pill').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    renderBody();
  });
};

function exportCSV(rows) {
  const header = ['Date','Previous Reading','Current Reading','Units','Rate','Fixed Charge','Tax %','Energy Charge','Tax Amount','Total Bill','Notes'];
  const lines = rows.map(r => [
    r.readingDate, r.previousReading, r.currentReading, r.units, r.rate, r.fixedCharge, r.taxPercent, r.energyCharge, r.taxAmount, r.totalBill, (r.notes||'').replace(/,/g,';'),
  ].join(','));
  const csv = [header.join(','), ...lines].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'wattwise-export.csv';
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  UI.toast('CSV exported', 'success');
}

/**
 * Real, offline PDF export. There's no bundled PDF library (that would break
 * the "zero external dependency, fully offline" requirement), so this builds
 * a clean printable report and hands off to the browser's native print
 * pipeline — every modern browser (Chrome, Edge, Safari, Firefox, and
 * Android's WebView/Chrome) offers "Save as PDF" as a print destination,
 * which produces a real PDF file with zero network access.
 */
function exportPDF(rows, rangeLabel, settings) {
  const totalUnits = rows.reduce((a, r) => a + r.units, 0);
  const totalCost = rows.reduce((a, r) => a + r.totalBill, 0);
  const generatedAt = new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });

  const tableRows = rows.map(r => `
    <tr>
      <td>${UI.fmtDate(r.readingDate)}</td>
      <td class="num">${UI.fmtUnits(r.previousReading)}</td>
      <td class="num">${UI.fmtUnits(r.currentReading)}</td>
      <td class="num">${UI.fmtUnits(r.units)}</td>
      <td class="num">${settings.currencySymbol}${r.rate}</td>
      <td class="num">${UI.fmtMoney(r.totalBill, settings)}</td>
    </tr>`).join('');

  const printEl = document.getElementById('print-report');
  printEl.innerHTML = `
    <div class="pr-header">
      <div class="pr-brand">⚡ WattWise</div>
      <div class="pr-meta">Electricity Usage Report — ${escapeHTML(rangeLabel)}<br>Generated ${generatedAt}</div>
    </div>

    <h2>Summary</h2>
    <div class="pr-stats">
      <div class="pr-stat"><div class="label">Total Units</div><div class="value">${UI.fmtUnits(totalUnits)} kWh</div></div>
      <div class="pr-stat"><div class="label">Total Cost</div><div class="value">${UI.fmtMoney(totalCost, settings)}</div></div>
      <div class="pr-stat"><div class="label">Readings</div><div class="value">${rows.length}</div></div>
      <div class="pr-stat"><div class="label">Avg / Reading</div><div class="value">${UI.fmtUnits(totalUnits / rows.length)} kWh</div></div>
    </div>

    <h2>Reading Details</h2>
    <table>
      <thead><tr>
        <th>Date</th><th class="num">Prev</th><th class="num">Curr</th><th class="num">Units</th><th class="num">Rate</th><th class="num">Bill</th>
      </tr></thead>
      <tbody>${tableRows}</tbody>
    </table>

    <div class="pr-footer">Generated by WattWise — all data stored locally on-device. No data is uploaded to any server.</div>
  `;

  // Give the browser a tick to lay out the print DOM before invoking print.
  requestAnimationFrame(() => requestAnimationFrame(() => window.print()));
}

/* ---------------- Settings ---------------- */
Pages.settings = async () => {
  const settings = App.settings;
  // Working copy — nothing here touches App.settings or the database until
  // the user presses "Save Changes". This is what the bottom Save button
  // controls: one explicit, atomic write instead of a save-per-field.
  const draft = { ...settings };

  App.setScreen(`
    <div class="page-header">
      <a class="back-btn" href="#/dashboard">${Icons.arrowLeft}</a>
      <h1>Settings</h1>
    </div>
    <div class="container" style="padding-top:0;padding-bottom:110px;">

      <div class="settings-section">
        <div class="settings-section-title">User Preferences</div>
        <div class="settings-card">
          <div class="settings-row">
            <div class="settings-row-label">${Icons.moon} Theme</div>
            <div class="select-wrap">
              <select class="select" id="set-theme">
                <option value="light" ${settings.theme==='light'?'selected':''}>Light</option>
                <option value="dark" ${settings.theme==='dark'?'selected':''}>Dark</option>
              </select>
              <span class="select-chevron">${Icons.chevronDown}</span>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-row-label">${Icons.globe} Language</div>
            <div class="select-wrap">
              <select class="select" id="set-language">
                <option ${settings.language==='English'?'selected':''}>English</option>
              </select>
              <span class="select-chevron">${Icons.chevronDown}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="settings-section">
        <div class="settings-section-title">Billing Preferences</div>
        <div class="settings-card">
          <div class="settings-row">
            <div class="settings-row-label">${Icons.wallet} Default Currency</div>
            <div class="select-wrap">
              <select class="select" id="set-currency">
                <option value="INR" ${settings.currency==='INR'?'selected':''}>Indian Rupee (₹ - INR)</option>
                <option value="USD" ${settings.currency==='USD'?'selected':''}>US Dollar ($ - USD)</option>
                <option value="EUR" ${settings.currency==='EUR'?'selected':''}>Euro (€ - EUR)</option>
                <option value="GBP" ${settings.currency==='GBP'?'selected':''}>British Pound (£ - GBP)</option>
              </select>
              <span class="select-chevron">${Icons.chevronDown}</span>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-row-label">${Icons.bolt} Default Rate per Unit</div>
            ${numberStepperHTML('set-rate', { value: settings.defaultRate, prefix: settings.currencySymbol, step: 0.5 })}
            <div class="field-hint">Used when creating new readings.</div>
          </div>
          <div class="settings-row">
            <div class="two-col">
              <div>
                <div class="settings-row-label">${Icons.fileText} Fixed Charge</div>
                ${numberStepperHTML('set-fixed', { value: settings.fixedCharge, prefix: settings.currencySymbol, step: 10 })}
              </div>
              <div>
                <div class="settings-row-label">${Icons.percent} Default Tax</div>
                ${numberStepperHTML('set-tax', { value: settings.defaultTax, step: 1 })}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="settings-section">
        <div class="settings-section-title">Application Preferences</div>
        <div class="settings-card">
          <div class="settings-row">
            <div class="settings-row-label">${Icons.ruler} Default Unit</div>
            <div class="select-wrap">
              <select class="select" id="set-unit">
                <option value="kWh" ${settings.defaultUnit==='kWh'?'selected':''}>kWh (Kilowatt-hour)</option>
              </select>
              <span class="select-chevron">${Icons.chevronDown}</span>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-row-label">${Icons.calendar} Date Format</div>
            <div class="select-wrap">
              <select class="select" id="set-dateformat">
                <option ${settings.dateFormat==='DD/MM/YYYY'?'selected':''}>DD/MM/YYYY</option>
                <option ${settings.dateFormat==='MM/DD/YYYY'?'selected':''}>MM/DD/YYYY</option>
              </select>
              <span class="select-chevron">${Icons.chevronDown}</span>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-row-label">${Icons.hash} Number Format</div>
            <div class="select-wrap">
              <select class="select" id="set-numformat">
                <option ${settings.numberFormat==='1,234.56'?'selected':''}>1,234.56</option>
                <option ${settings.numberFormat==='1.234,56'?'selected':''}>1.234,56</option>
              </select>
              <span class="select-chevron">${Icons.chevronDown}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="settings-section">
        <div class="settings-section-title">Data Management</div>
        <div class="settings-card">
          <div class="settings-action-row">
            <div class="settings-action-label">${Icons.fileText}<div><div class="settings-action-title">Export Data</div><div class="settings-action-sub">Export all readings to CSV or JSON</div></div></div>
            <button class="btn btn-outline btn-sm" id="export-data-btn">Export</button>
          </div>
          <div class="settings-action-row">
            <div class="settings-action-label">${Icons.upload}<div><div class="settings-action-title">Import Data</div><div class="settings-action-sub">Restore readings from a backup</div></div></div>
            <button class="btn btn-outline btn-sm" id="import-data-btn">Import</button>
            <input type="file" id="import-file-input" accept="application/json" class="visually-hidden">
          </div>
          <div class="settings-action-row">
            <div class="settings-action-label danger">${Icons.trash}<div><div class="settings-action-title danger">Reset All Data</div><div class="settings-action-sub">Delete all stored readings and settings</div></div></div>
            <button class="btn btn-danger-outline btn-sm" id="reset-data-btn">Reset</button>
          </div>
        </div>
      </div>

      <div class="card about-card">
        <div class="about-logo">${Icons.bolt}</div>
        <div style="font-weight:700;color:var(--color-primary);">WattWise</div>
        <div class="about-version">Version 1.1.0</div>
        <div class="about-storage-row"><span>Storage</span><span>Local Device (IndexedDB)</span></div>
        <div class="about-privacy-note">${Icons.shield} No user data is uploaded to any server. Your information stays private on your device.</div>
        <div class="about-license">MIT License</div>
        <div class="about-credit">Made by Arnab Ghosh</div>
      </div>
    </div>

    <div class="settings-save-bar" id="settings-save-bar">
      <button class="btn btn-primary" id="save-settings-btn">${Icons.check} Save Changes</button>
    </div>
  `);

  // Every field below only updates the local `draft` object (and, for a few
  // fields, a live visual preview). Nothing touches App.settings or the
  // database until "Save Changes" is pressed — that single button click is
  // the only write, which is also what makes it impossible for two fields
  // to race each other the way currency + currencySymbol used to.
  document.getElementById('set-theme').addEventListener('change', (e) => { draft.theme = e.target.value; });
  document.getElementById('set-language').addEventListener('change', (e) => { draft.language = e.target.value; });

  document.getElementById('set-currency').addEventListener('change', (e) => {
    const symbols = { INR: '₹', USD: '$', EUR: '€', GBP: '£' };
    draft.currency = e.target.value;
    draft.currencySymbol = symbols[e.target.value] || '₹';
    // Live-preview the new symbol on the rate/fixed-charge steppers so the
    // change is visible immediately, even though it isn't saved yet.
    document.querySelectorAll('.stepper-prefix-wrap .prefix').forEach((el) => { el.textContent = draft.currencySymbol; });
  });

  UI.wireStepper(document.getElementById('set-rate-stepper'), { min: 0, step: 0.5, onChange: (v) => { draft.defaultRate = v; } });
  UI.wireStepper(document.getElementById('set-fixed-stepper'), { min: 0, step: 10, onChange: (v) => { draft.fixedCharge = v; } });
  UI.wireStepper(document.getElementById('set-tax-stepper'), { min: 0, max: 100, step: 1, onChange: (v) => { draft.defaultTax = v; } });

  document.getElementById('set-rate').addEventListener('input', (e) => { draft.defaultRate = parseFloat(e.target.value) || 0; });
  document.getElementById('set-fixed').addEventListener('input', (e) => { draft.fixedCharge = parseFloat(e.target.value) || 0; });
  document.getElementById('set-tax').addEventListener('input', (e) => { draft.defaultTax = parseFloat(e.target.value) || 0; });

  document.getElementById('set-unit').addEventListener('change', (e) => { draft.defaultUnit = e.target.value; });
  document.getElementById('set-dateformat').addEventListener('change', (e) => { draft.dateFormat = e.target.value; });
  document.getElementById('set-numformat').addEventListener('change', (e) => { draft.numberFormat = e.target.value; });

  document.getElementById('save-settings-btn').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    const original = btn.innerHTML;
    btn.innerHTML = 'Saving…';
    try {
      await App.saveSettingsPatch(draft);
      UI.applyTheme(draft.theme);
      UI.toast('Settings saved', 'success');
    } finally {
      btn.disabled = false;
      btn.innerHTML = original;
    }
  });

  document.getElementById('export-data-btn').addEventListener('click', async () => {
    const rows = await Storage.getAllReadings();
    const s = await Storage.getSettings();
    const payload = JSON.stringify({ readings: rows, settings: s, exportedAt: new Date().toISOString() }, null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'wattwise-backup.json';
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
    UI.toast('Data exported', 'success');
  });

  document.getElementById('import-data-btn').addEventListener('click', () => document.getElementById('import-file-input').click());
  document.getElementById('import-file-input').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (Array.isArray(data.readings)) {
        await Storage.bulkImportReadings(data.readings);
      }
      if (data.settings) {
        await Storage.saveSettings({ ...Storage.DEFAULT_SETTINGS, ...data.settings });
        await App.refreshSettings();
      }
      UI.toast('Data imported successfully', 'success');
      Router.navigate('/dashboard');
    } catch (err) {
      UI.toast('Import failed — invalid file', 'error');
    }
  });

  document.getElementById('reset-data-btn').addEventListener('click', () => {
    UI.showModal({
      title: 'Reset all data?',
      text: 'This permanently deletes every reading and resets all settings on this device. This cannot be undone.',
      confirmLabel: 'Reset Everything',
      danger: true,
      onConfirm: async () => {
        await Storage.resetAll();
        await App.refreshSettings();
        UI.toast('All data has been reset', 'success');
        Router.navigate('/dashboard');
      },
    });
  });
};
