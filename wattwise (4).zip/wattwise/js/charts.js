/* WattWise — charts.js
   Lightweight canvas chart renderers (no external CDN dependency, works fully offline). */

const Charts = {
  _dpr() { return window.devicePixelRatio || 1; },

  _setup(canvas, hCssHeight) {
    const dpr = Charts._dpr();
    const cssWidth = canvas.parentElement.clientWidth;
    canvas.style.width = cssWidth + 'px';
    canvas.style.height = hCssHeight + 'px';
    canvas.width = cssWidth * dpr;
    canvas.height = hCssHeight * dpr;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { ctx, w: cssWidth, h: hCssHeight };
  },

  bar(canvas, data, opts = {}) {
    const height = opts.height || 170;
    const { ctx, w, h } = Charts._setup(canvas, height);
    ctx.clearRect(0, 0, w, h);
    if (!data.length) return;

    const padTop = 10, padBottom = 22, padSide = 6;
    const chartH = h - padTop - padBottom;
    const max = Math.max(...data.map(d => d.value), 1);
    const barGap = 6;
    const barW = Math.max(4, (w - padSide * 2 - barGap * (data.length - 1)) / data.length);

    data.forEach((d, i) => {
      const x = padSide + i * (barW + barGap);
      const barH = Math.max(3, (d.value / max) * chartH);
      const y = padTop + (chartH - barH);
      ctx.fillStyle = d.highlight ? '#2563EB' : '#BFDBFE';
      roundRectTop(ctx, x, y, barW, barH, Math.min(5, barW / 2));
      ctx.fill();
    });

    ctx.fillStyle = '#64748B';
    ctx.font = '11px Inter, sans-serif';
    ctx.textBaseline = 'top';
    const labelIdxs = [0, Math.floor(data.length / 2), data.length - 1];
    labelIdxs.forEach((idx) => {
      if (idx < 0 || idx >= data.length) return;
      const x = padSide + idx * (barW + barGap);
      ctx.textAlign = idx === 0 ? 'left' : idx === data.length - 1 ? 'right' : 'center';
      ctx.fillText(data[idx].label, x + (idx === data.length - 1 ? barW : 0), h - padBottom + 6);
    });
  },

  area(canvas, data, opts = {}) {
    const height = opts.height || 170;
    const { ctx, w, h } = Charts._setup(canvas, height);
    ctx.clearRect(0, 0, w, h);
    if (!data.length) return;

    const padTop = 14, padBottom = 22, padSide = 4;
    const chartW = w - padSide * 2;
    const chartH = h - padTop - padBottom;
    const max = Math.max(...data.map(d => d.value), 1);
    const min = Math.min(...data.map(d => d.value), 0);
    const range = max - min || 1;

    const pts = data.map((d, i) => ({
      x: padSide + (data.length === 1 ? chartW / 2 : (i / (data.length - 1)) * chartW),
      y: padTop + chartH - ((d.value - min) / range) * chartH,
    }));

    ctx.beginPath();
    ctx.moveTo(pts[0].x, padTop + chartH);
    pts.forEach((p) => ctx.lineTo(p.x, p.y));
    ctx.lineTo(pts[pts.length - 1].x, padTop + chartH);
    ctx.closePath();
    const grad = ctx.createLinearGradient(0, padTop, 0, padTop + chartH);
    grad.addColorStop(0, 'rgba(37,99,235,0.28)');
    grad.addColorStop(1, 'rgba(37,99,235,0.02)');
    ctx.fillStyle = grad;
    ctx.fill();

    ctx.beginPath();
    pts.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
    ctx.strokeStyle = '#2563EB';
    ctx.lineWidth = 2.5;
    ctx.lineJoin = 'round';
    ctx.stroke();

    ctx.fillStyle = '#64748B';
    ctx.font = '11px Inter, sans-serif';
    ctx.textBaseline = 'top';
    const labelIdxs = [0, Math.floor(data.length / 2), data.length - 1];
    labelIdxs.forEach((idx) => {
      if (idx < 0 || idx >= data.length) return;
      ctx.textAlign = idx === 0 ? 'left' : idx === data.length - 1 ? 'right' : 'center';
      ctx.fillText(data[idx].label, pts[idx].x, h - padBottom + 6);
    });
  },

  donut(canvas, segments, opts = {}) {
    const size = opts.size || 170;
    const { ctx, w, h } = Charts._setup(canvas, size);
    ctx.clearRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2;
    const radius = Math.min(w, h) / 2 - 6;
    const innerRadius = radius * 0.62;
    const total = segments.reduce((a, s) => a + s.value, 0) || 1;

    let start = -Math.PI / 2;
    segments.forEach((s) => {
      const angle = (s.value / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, start, start + angle);
      ctx.arc(cx, cy, innerRadius, start + angle, start, true);
      ctx.closePath();
      ctx.fillStyle = s.color;
      ctx.fill();
      start += angle;
    });

    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-text').trim() || '#0F172A';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '700 20px Sora, sans-serif';
    ctx.fillText(opts.centerLabel || '100%', cx, cy - 8);
    ctx.font = '11px Inter, sans-serif';
    ctx.fillStyle = '#64748B';
    ctx.fillText(opts.centerSubLabel || '', cx, cy + 12);
  },
};

function roundRectTop(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x, y + h);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h);
  ctx.closePath();
}

window.Charts = Charts;
